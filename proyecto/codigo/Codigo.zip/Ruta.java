/**
 * Esta Clase aalmacena la informacion de una ruta
 *
 * @author  Santiago Soto y Kevin Gomez
 * @version 1.0
 * @since   2018-05-12
 */
public class Ruta {
    String parte1;
    float tCarga;
    short tipoS;
    String parte2;
    float bateriaFinal;

    public Ruta() {};
}